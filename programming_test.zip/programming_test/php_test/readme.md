# PHP Test

In this folder you will find two files getcart.php and index.php. Take a moment
to study getcart.php but do not modify it. The file getcart.php declares a 
global function called `getCart()` which returns an array representing a 
shopping cart. 

The file index.php will be the console entry point for the code you will write 
to complete the following tasks. The expected output of each task is provided 
after its description.

###Tasks

1. Output whether or not the shopping cart contains any line items with 
duplicate non-empty upcs.
    ```
    Duplicate UPCs is false.
    ```

2. Output the cheapest shipping provider that qualifies for this shopping cart.
Call the global function `getShippingProviders()` to retrieve an associative 
array defining available shipping providers. Compare the range in the 
`selection_rule` field against the total of the target field in the cart to
determine which shipping methods qualify.
    ```
    Shipping is Usps Standard Mail for 80.00.
    ```

3. Output the cheapest shipping provider that qualifies for this shopping cart
per applicable category. Assume that all distinct sets of 
`applicable_categories` between shipping providers are mutually exclusive. 
Compare the range in the `selection_rule` field against the total of the target
field in a given category to determine which shipping methods qualify for that
category.
    ```
    Shipping for Accessories is Usps Priority Mail for 120.00.
    Shipping for Bikes is Fedex Ground for 80.00.
    ```
