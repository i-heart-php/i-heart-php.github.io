<?php
/*
 * DO NOT MODIFY THIS FILE
 */

function getCart()
{
    return [
        'line_items' => [
            [
                'id' => '1001',
                'price' => '639.99',
                'quantity' => '1',
                'sku' => 'BIKE-1',
                'title' => 'Bicycle',
                'upc' => '9090909090909',
                'variant' => 'Medium / Red',
                'weight_g' => '1000',
                'categories' => [
                    'Bikes',
                ],
            ],
            [
                'id' => '1002',
                'price' => '10.00',
                'quantity' => '2',
                'sku' => 'BELL-1',
                'title' => 'Bell',
                'upc' => '',
                'variant' => 'Default',
                'weight_g' => '150.00',
                'categories' => [
                    'Accessories',
                    'Bells',
                ],
            ],
            [
                'id' => '1003',
                'price' => '10.00',
                'quantity' => '2',
                'sku' => 'BAG-1',
                'title' => 'Bag',
                'upc' => '0909090909090',
                'variant' => 'Navy Blue',
                'weight_g' => '100.00',
                'categories' => [
                    'Accessories',
                    'Bags',
                ],
            ],
        ],
    ];
}

function getShippingProviders()
{
    return [
        [
            'id' => '1001',
            'price' => '80.00',
            'source' => 'fedex',
            'title' => 'Ground',
            'selection_rule' => [
                'type' => 'weight_g',
                'min' => '0.0',
                'max' => '1500.0',
                'applicable_categories' => [
                    'Bikes',
                    'E-Bikes',
                ],
            ],
        ],
        [
            'id' => '1002',
            'price' => '120.00',
            'source' => 'fedex',
            'title' => 'Freight',
            'selection_rule' => [
                'type' => 'weight_g',
                'min' => '1500.0',
                'max' => null,
                'applicable_categories' => [
                    'E-Bikes',
                    'Bikes',
                ],
            ],
        ],
        [
            'id' => '1003',
            'price' => '80.00',
            'source' => 'usps',
            'title' => 'Standard Mail',
            'selection_rule' => [
                'type' => 'price',
                'min' => '675.00',
                'max' => null,
                'applicable_categories' => [
                    'Accessories',
                ],
            ],
        ],
        [
            'id' => '1004',
            'price' => '120.00',
            'source' => 'usps',
            'title' => 'Priority Mail',
            'selection_rule' => [
                'type' => 'price',
                'min' => '0.00',
                'max' => '675.00',
                'applicable_categories' => [
                    'Accessories',
                ],
            ],
        ],
    ];
}
