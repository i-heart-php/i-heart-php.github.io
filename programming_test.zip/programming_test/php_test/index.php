<?php
require __DIR__ . '/getcart.php';

$cart = getCart()['line_items'];
$shippingProviders = getShippingProviders();
$upcs = array();
$categories = array();
$total = 0.00;

//Duplicate UPCs is false.
foreach ($cart as $key => $lineItem) {
    if (empty($lineItem['upc']) || !in_array($lineItem['upc'], $upcs)) {
        if (!empty($lineItem['upc'])) {
            $upcs[] = $lineItem['upc'];
        }
        $categories = array_merge($categories, $lineItem['categories']);
        $total += $lineItem['price'] * $lineItem['quantity'];
    } else {
        echo "Duplicate UPCs is false.";
        exit;
    }
}

$recommendedProvider = false;
$shippingCost = PHP_FLOAT_MAX;
foreach ($shippingProviders as $provider) {
    if ($total > $provider['selection_rule']['min'] &&
        $total < $provider['selection_rule']['max'] &&
        $shippingCost > $provider['price']) {
        $recommendedProvider = $provider;
        $shippingCost = $provider['price'];
    }
}

//cheapest shipping provider based on totals
echo "Shipping is {$recommendedProvider['title']} for $shippingCost." . PHP_EOL;

//cheapest shipping provider based on categories
foreach (array_unique($categories) as $category) {
    $recommendedProvider = false;
    $shippingCost = PHP_FLOAT_MAX;
    foreach ($shippingProviders as $provider) {
        if (in_array($category, $provider['selection_rule']['applicable_categories']) &&
            $shippingCost > $provider['price']
        ) {
            $recommendedProvider = $provider;
            $shippingCost = $provider['price'];
        }
    }
    echo ($recommendedProvider) ? "Shipping for $category is {$recommendedProvider['title']} for {$shippingCost}." . PHP_EOL : "";
}