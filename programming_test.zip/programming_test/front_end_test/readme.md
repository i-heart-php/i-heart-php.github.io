# HTML/CSS/JS Test

In this folder you will find two files getcart.js and index.html. Take a moment
to study getcart.js but do not modify it. The file getcart.js declares a 
global function called `getCart()` which returns a JSON object representing a 
shopping cart. 

The file index.html has been created with some boiler plate to get you started
but feel free to modify it however you wish to complete the following tasks.
You will be expected present the given data with a user friendly layout and 
make the page look nice.

###Tasks

1. Display each line item retrieved from `getCart()`. Each line item must 
include a thumbnail, product name, sku, quantity, price, and line total.

2. Display the subtotal, shipping, total tax, and total for the cart.

3. Make the chosen shipping provider editable using the given value as the 
default. Allow the user to pick one of the shipping providers returned by 
`getShippingProviders()` and update the cart values.

4. Make the quantity value editable with the given quantity as the default 
value. Update the cart totals when a quantity is changed. 
